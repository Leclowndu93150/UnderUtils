# Flashlight Shader
This shader makes the dark more intense in Minecraft, and gives the player a tool to explore it.
## Flashlight
Torches or any light-emitting objects will act as a flashlight if held in your hand or offhand.
## Increased Darkness
If you are in a decently well lit area, you can see normally.   
If there is a small amount of light (like on the surface at night), you can see a small area around you in black and white. The size of this area depends on the phase of the moon.   
If there is no light at all, well, you will be able to see nothing at all.